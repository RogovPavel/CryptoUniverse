<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1><a href="<?php echo e(url('/admin/')); ?>">Админка</a></h1>
        </div>    
    </div>
    <div class="row">
        <div class="col-md-12">
            <h1><a href="<?php echo e(url('/goods')); ?>">Просмотр товаров</a></h1>
        </div>    
    </div>    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>