<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Наименование товара</th>
                    <th scope="col">Цена</th>
                    <th scope="col">Видимость</th>
                    <th scope="col">Дейтсвие</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($good->id); ?></td>
                        <td><?php echo e($good->name); ?></td>
                        <td><?php echo e($good->price); ?></td>
                        <td><?php echo e($good->hide ? 'Нет' : 'Да'); ?></td>
                        <td>
                            <a href="<?php echo e(route('goods.edit', ['id' => $good->id])); ?>">Изменить</a>
                            <form action="<?php echo e(route('goods.destroy', ['id' => $good->id])); ?>" method="POST">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button onclick="return confirm('Вы уверены, что хотите удалить этот товар?')" style="background: transparent; border: 0;padding: 0;">
                                    <a>Удалить</a>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="row">
        <?php echo e($goods->links()); ?>

    </div>
    <div class="row">
        <a class="btn btn-success" href="<?php echo e(route('goods.create')); ?>" role="button">Создать новый товар</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>