<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Товар</th>
                    <th scope="col">Пользователь</th>
                    <th scope="col">Продано</th>
                    <th scope="col">Дейтсвие</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->good['name']); ?></td>
                        <td><?php echo e($order->user['name']); ?></td>
                        <td><?php echo e($order->sale ? 'Да':'Нет'); ?></td>
                        <td>
                            <form action="<?php echo e(route('orders.sale', ['id' => $order->id])); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <button onclick="return confirm('Вы уверены, что хотите продать товар?')" style="background: transparent; border: 0;padding: 0;">
                                    <a>Продать</a>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="row">
        <?php echo e($orders->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>