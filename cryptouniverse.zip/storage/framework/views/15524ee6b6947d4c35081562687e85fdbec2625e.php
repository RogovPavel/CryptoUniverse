<?php $__env->startSection('content'); ?>
    
<style>
    .goods-item {
        border: 1px solid #d3e0e9;
        border-radius: 3px;
        padding: 6px;
        margin-bottom: 20px;
        min-width: 200px;
    }
    
    .goods-item .item-body {
        margin: 20px 0px;
        min-height: 100px;
        
    }
</style>
    

<div class="container">
    <div class="row text-center">
        <h1>Товары</h1>
    </div>
    <div class="row">
        <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="goods-item text-center">
                    <h3><?php echo e($good->name); ?></h3>
                    <div class="item-body">
                        <div class="item-text"></div>
                        <div class="item-price">Цена: <?php echo e($good->price); ?></div>
                    </div>
                    <form method="POST" action="<?php echo e(route('goods.buy', ['id' => $good->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <button onclick="return confirm('Вы уверены, что хотите купить этот товар?')" class="btn btn-primary btn-block">Купить</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
    <div class="row">
        <?php echo e($goods->links()); ?>

    </div>
    <div class="row text-center">
        <h1>Мои заказы</h1>
    </div>
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID Заказа</th>
                    <th scope="col">Наименование товара</th>
                    <th scope="col">Продано</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->good['name']); ?></td>
                        <td><?php echo e($order->sale ? 'Да':'Нет'); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="row">
        <?php echo e($orders->links()); ?>

    </div>
    
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>